/*
  # Fix exercise permissions

  1. Changes
    - Add explicit delete policy for trainers
    - Ensure proper RLS policies for exercise management
    - Fix storage permissions for exercise media

  2. Security
    - Enable RLS on exercises table
    - Add policies for authenticated users
    - Add specific policies for trainers
*/

-- Ensure RLS is enabled
ALTER TABLE exercises ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Everyone can view exercises" ON exercises;
DROP POLICY IF EXISTS "Trainers can create exercises" ON exercises;
DROP POLICY IF EXISTS "Trainers can update their exercises" ON exercises;
DROP POLICY IF EXISTS "Trainers can delete their exercises" ON exercises;

-- Create comprehensive policies
CREATE POLICY "Everyone can view exercises"
ON exercises FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Trainers can create exercises"
ON exercises FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role = 'trainer'
  )
);

CREATE POLICY "Trainers can update their exercises"
ON exercises FOR UPDATE
TO authenticated
USING (
  created_by = auth.uid() 
  AND EXISTS (
    SELECT 1
    FROM user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role = 'trainer'
  )
)
WITH CHECK (
  created_by = auth.uid()
  AND EXISTS (
    SELECT 1
    FROM user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role = 'trainer'
  )
);

CREATE POLICY "Trainers can delete their exercises"
ON exercises FOR DELETE
TO authenticated
USING (
  created_by = auth.uid()
  AND EXISTS (
    SELECT 1
    FROM user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role = 'trainer'
  )
);

-- Drop existing storage policies
DROP POLICY IF EXISTS "Trainers can manage exercise media" ON storage.objects;

-- Create storage policies for exercise media
CREATE POLICY "Trainers can manage exercise media"
ON storage.objects
FOR ALL
TO authenticated
USING (
  bucket_id = 'exercises'
  AND EXISTS (
    SELECT 1
    FROM user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role = 'trainer'
  )
)
WITH CHECK (
  bucket_id = 'exercises'
  AND EXISTS (
    SELECT 1
    FROM user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role = 'trainer'
  )
);