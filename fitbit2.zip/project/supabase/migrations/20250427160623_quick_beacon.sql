-- Create storage bucket for exercise media
INSERT INTO storage.buckets (id, name, public)
VALUES ('exercises', 'exercises', true)
ON CONFLICT (id) DO NOTHING;

-- Drop existing policies if they exist
DO $$
BEGIN
    DROP POLICY IF EXISTS "Trainers can upload exercise media" ON storage.objects;
    DROP POLICY IF EXISTS "Anyone can view exercise media" ON storage.objects;
END $$;

-- Storage policies for exercise media
CREATE POLICY "Trainers can upload exercise media"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'exercises' AND
  EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role = 'trainer'
  )
);

CREATE POLICY "Anyone can view exercise media"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'exercises');