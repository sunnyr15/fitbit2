/*
  # Create trainer-related tables

  1. New Tables
    - `user_roles`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `role` (text)
      - `created_at` (timestamp)

    - `exercises`
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text)
      - `video_url` (text)
      - `tags` (text[])
      - `created_by` (uuid, references auth.users)
      - `created_at` (timestamp)

    - `workouts`
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text)
      - `exercises` (jsonb)
      - `created_by` (uuid, references auth.users)
      - `created_at` (timestamp)

    - `programs`
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text)
      - `weeks` (jsonb)
      - `created_by` (uuid, references auth.users)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for trainers to manage their content
    - Add policies for users to view content
*/

-- Create user_roles table first since other tables depend on it
CREATE TABLE IF NOT EXISTS user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  role text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own roles"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "System can manage roles"
  ON user_roles
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Create exercises table
CREATE TABLE IF NOT EXISTS exercises (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  video_url text NOT NULL,
  tags text[] DEFAULT '{}',
  created_by uuid REFERENCES auth.users(id) NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE exercises ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Trainers can create exercises"
  ON exercises
  FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid()
    AND role = 'trainer'
  ));

CREATE POLICY "Trainers can update their exercises"
  ON exercises
  FOR UPDATE
  TO authenticated
  USING (created_by = auth.uid())
  WITH CHECK (EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid()
    AND role = 'trainer'
  ));

CREATE POLICY "Everyone can view exercises"
  ON exercises
  FOR SELECT
  TO authenticated
  USING (true);

-- Create workouts table
CREATE TABLE IF NOT EXISTS workouts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  exercises jsonb NOT NULL,
  created_by uuid REFERENCES auth.users(id) NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE workouts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Trainers can create workouts"
  ON workouts
  FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid()
    AND role = 'trainer'
  ));

CREATE POLICY "Trainers can update their workouts"
  ON workouts
  FOR UPDATE
  TO authenticated
  USING (created_by = auth.uid())
  WITH CHECK (EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid()
    AND role = 'trainer'
  ));

CREATE POLICY "Everyone can view workouts"
  ON workouts
  FOR SELECT
  TO authenticated
  USING (true);

-- Create programs table
CREATE TABLE IF NOT EXISTS programs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  weeks jsonb NOT NULL,
  created_by uuid REFERENCES auth.users(id) NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE programs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Trainers can create programs"
  ON programs
  FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid()
    AND role = 'trainer'
  ));

CREATE POLICY "Trainers can update their programs"
  ON programs
  FOR UPDATE
  TO authenticated
  USING (created_by = auth.uid())
  WITH CHECK (EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid()
    AND role = 'trainer'
  ));

CREATE POLICY "Everyone can view programs"
  ON programs
  FOR SELECT
  TO authenticated
  USING (true);