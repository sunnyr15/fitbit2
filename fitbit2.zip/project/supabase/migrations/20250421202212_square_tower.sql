/*
  # Add profile fields and storage setup

  1. Changes
    - Add profile fields to user_roles table
    - Create storage bucket for profile photos
    - Add policies for profile photo access

  2. Security
    - Only authenticated users can access their own photos
    - Public read access for profile photos
*/

-- Add profile fields to user_roles table
ALTER TABLE user_roles
ADD COLUMN IF NOT EXISTS full_name text,
ADD COLUMN IF NOT EXISTS avatar_url text;

-- Create storage bucket for profile photos
INSERT INTO storage.buckets (id, name, public)
VALUES ('profile_photos', 'profile_photos', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies
CREATE POLICY "Users can upload their own avatar"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'profile_photos' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Anyone can view profile photos"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'profile_photos');